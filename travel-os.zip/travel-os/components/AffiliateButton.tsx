"use client";

import type { AffiliateLink } from "@/lib/utils";

interface AffiliateButtonProps {
  link: AffiliateLink;
}

export default function AffiliateButton({ link }: AffiliateButtonProps) {
  const handleClick = () => {
    // Fire a client-side analytics ping as well (best-effort)
    try {
      fetch("/api/analytics/event", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: "affiliate_clicked_client",
          payload: { partner: link.partner, label: link.label },
        }),
        keepalive: true,
      }).catch(() => {});
    } catch {
      // Swallow — analytics must not block navigation
    }
  };

  return (
    <a
      href={link.clickUrl}
      target="_blank"
      rel="noopener noreferrer"
      onClick={handleClick}
      className="group flex items-center gap-3 px-5 py-3.5 rounded-xl bg-white/70 hover:bg-white border border-sand/40 hover:border-terracotta/30 hover:shadow-sm transition-all duration-150"
    >
      {/* Icon */}
      <span className="text-2xl flex-shrink-0">{link.icon}</span>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <div className="font-body font-medium text-ink text-sm leading-tight">
          {link.label}
        </div>
        <div className="font-body text-xs text-ink/40 mt-0.5 truncate">
          {link.description}
        </div>
      </div>

      {/* Arrow */}
      <span className="text-ink/25 group-hover:text-terracotta group-hover:translate-x-0.5 transition-all text-sm flex-shrink-0">
        →
      </span>
    </a>
  );
}
