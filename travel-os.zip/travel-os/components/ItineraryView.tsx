"use client";

import { useState } from "react";
import AffiliateButton from "./AffiliateButton";
import type { ItineraryResponse } from "@/lib/utils";

interface ItineraryViewProps {
  itinerary: ItineraryResponse;
  onReset: () => void;
}

/**
 * Converts a subset of Markdown to HTML.
 * Handles: h1–h3, bold, italic, hr, ul/li, ol/li, blockquote,
 * inline code, tables, and paragraphs.
 * Safe for our controlled Claude output.
 */
function markdownToHtml(md: string): string {
  let html = md
    // Escape raw HTML (safety)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")

    // Headings
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^# (.+)$/gm, "<h1>$1</h1>")

    // Bold + italic
    .replace(/\*\*\*(.+?)\*\*\*/g, "<strong><em>$1</em></strong>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/__(.+?)__/g, "<strong>$1</strong>")
    .replace(/_(.+?)_/g, "<em>$1</em>")

    // Inline code
    .replace(/`(.+?)`/g, "<code>$1</code>")

    // Horizontal rules
    .replace(/^---$/gm, "<hr />")

    // Blockquotes
    .replace(/^&gt; (.+)$/gm, "<blockquote>$1</blockquote>")

    // Tables (simple: | col | col |)
    // We handle tables as a block — replace entire table with an HTML table
    ;

  // ── Table processing ────────────────────────────────────────
  html = html.replace(
    /((?:^\|.+\|\s*\n)+)/gm,
    (tableBlock) => {
      const rows = tableBlock
        .trim()
        .split("\n")
        .filter((r) => r.trim() && !r.match(/^\|[-| :]+\|$/));

      if (rows.length === 0) return tableBlock;

      const toCell = (row: string, tag: string) =>
        row
          .split("|")
          .slice(1, -1)
          .map((cell) => `<${tag}>${cell.trim()}</${tag}>`)
          .join("");

      const [headerRow, ...bodyRows] = rows;
      const thead = `<thead><tr>${toCell(headerRow, "th")}</tr></thead>`;
      const tbody = bodyRows
        .map((r) => `<tr>${toCell(r, "td")}</tr>`)
        .join("");

      return `<div class="overflow-x-auto my-4"><table class="w-full text-sm border-collapse">${thead}<tbody>${tbody}</tbody></table></div>`;
    }
  );

  // ── Lists ────────────────────────────────────────────────────
  // Unordered
  html = html.replace(
    /((?:^[-*] .+\n?)+)/gm,
    (block) => {
      const items = block
        .trim()
        .split("\n")
        .map((line) => `<li>${line.replace(/^[-*] /, "")}</li>`)
        .join("");
      return `<ul>${items}</ul>`;
    }
  );

  // Ordered
  html = html.replace(
    /((?:^\d+\. .+\n?)+)/gm,
    (block) => {
      const items = block
        .trim()
        .split("\n")
        .map((line) => `<li>${line.replace(/^\d+\. /, "")}</li>`)
        .join("");
      return `<ol>${items}</ol>`;
    }
  );

  // ── Paragraphs (anything not already wrapped) ────────────────
  html = html
    .split(/\n{2,}/)
    .map((block) => {
      const b = block.trim();
      if (!b) return "";
      // Already block-level HTML
      if (/^<(h[1-6]|ul|ol|blockquote|hr|table|div)/.test(b)) return b;
      // Single newlines become <br>
      return `<p>${b.replace(/\n/g, "<br />")}</p>`;
    })
    .join("\n");

  return html;
}

export default function ItineraryView({ itinerary, onReset }: ItineraryViewProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(itinerary.markdown);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Clipboard not available
    }
  };

  const htmlContent = markdownToHtml(itinerary.markdown);
  const hasAffiliateLinks = itinerary.affiliateLinks.length > 0;

  return (
    <div className="max-w-3xl mx-auto animate-fade-up">
      {/* ── Header ──────────────────────────────────────────── */}
      <div className="flex items-start justify-between gap-4 mb-6">
        <div>
          <p className="text-xs uppercase tracking-widest text-ink/30 font-body mb-1">
            Your itinerary
          </p>
          <h2 className="font-display text-2xl font-semibold text-ink leading-tight">
            {itinerary.destination}
          </h2>
          <p className="text-sm text-ink/40 font-body mt-0.5">
            {itinerary.duration}-day trip · Generated just now
          </p>
        </div>

        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-sand/40 bg-white/60 hover:bg-white text-xs font-body text-ink/50 hover:text-ink transition-all"
          >
            {copied ? "✓ Copied" : "Copy"}
          </button>
          <button
            onClick={onReset}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-sand/40 bg-white/60 hover:bg-white text-xs font-body text-ink/50 hover:text-ink transition-all"
          >
            New trip
          </button>
        </div>
      </div>

      {/* ── Affiliate links ──────────────────────────────────── */}
      {hasAffiliateLinks && (
        <div className="mb-8 p-4 rounded-2xl bg-parchment-50/80 border border-sand/30">
          <p className="text-xs uppercase tracking-widest text-ink/30 font-body mb-3">
            Book your trip
          </p>
          <div className="grid sm:grid-cols-2 gap-2">
            {itinerary.affiliateLinks.map((link) => (
              <AffiliateButton key={link.partner} link={link} />
            ))}
          </div>
          <p className="text-[10px] text-ink/25 font-body mt-3 leading-relaxed">
            Links marked above are affiliate links. Travel OS may earn a small
            commission at no extra cost to you.
          </p>
        </div>
      )}

      {/* ── Itinerary content ────────────────────────────────── */}
      <div className="bg-white/50 rounded-2xl border border-sand/20 p-6 md:p-8 shadow-sm">
        <div
          className="itinerary-content"
          dangerouslySetInnerHTML={{ __html: htmlContent }}
        />
      </div>

      {/* ── Bottom CTA ───────────────────────────────────────── */}
      <div className="mt-8 text-center space-y-3">
        {hasAffiliateLinks && (
          <div className="grid sm:grid-cols-2 gap-2 max-w-sm mx-auto">
            {itinerary.affiliateLinks.slice(0, 2).map((link) => (
              <AffiliateButton key={link.partner} link={link} />
            ))}
          </div>
        )}
        <button
          onClick={onReset}
          className="text-sm font-body text-ink/40 hover:text-ink transition-colors"
        >
          ← Plan another trip
        </button>
      </div>
    </div>
  );
}
