"use client";

import { useState, useEffect } from "react";
import type { TripFormData, BudgetLevel } from "@/lib/utils";
import { INTEREST_OPTIONS, clamp } from "@/lib/utils";

interface TripFormProps {
  onSubmit: (data: TripFormData) => void;
  prefillDestination?: string;
}

const BUDGET_OPTIONS: { value: BudgetLevel; label: string; desc: string }[] = [
  { value: "budget", label: "Budget", desc: "Hostels · Street food" },
  { value: "mid", label: "Mid-Range", desc: "3★ hotels · Restaurants" },
  { value: "premium", label: "Premium", desc: "5★ hotels · Fine dining" },
];

export default function TripForm({ onSubmit, prefillDestination = "" }: TripFormProps) {
  const [destination, setDestination] = useState(prefillDestination);
  const [origin, setOrigin] = useState("");
  const [duration, setDuration] = useState(7);
  const [travelers, setTravelers] = useState(2);
  const [budget, setBudget] = useState<BudgetLevel>("mid");
  const [departureDate, setDepartureDate] = useState("");
  const [interests, setInterests] = useState<string[]>([]);
  const [showInterests, setShowInterests] = useState(false);

  useEffect(() => {
    if (prefillDestination) setDestination(prefillDestination);
  }, [prefillDestination]);

  const toggleInterest = (interest: string) => {
    setInterests((prev) =>
      prev.includes(interest)
        ? prev.filter((i) => i !== interest)
        : [...prev, interest]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination.trim() || !origin.trim()) return;

    onSubmit({
      destination: destination.trim(),
      origin: origin.trim(),
      duration: clamp(duration, 1, 30),
      travelers: clamp(travelers, 1, 20),
      budget,
      departureDate: departureDate || undefined,
      interests: interests.length > 0 ? interests : undefined,
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* ── Destination ───────────────────────────────────── */}
      <div className="space-y-1.5">
        <label className="block text-xs font-medium uppercase tracking-widest text-ink/40">
          Where to?
        </label>
        <input
          type="text"
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          placeholder="Tokyo, Japan"
          required
          className="w-full px-4 py-3 rounded-xl bg-white/70 border border-sand/40 focus:border-terracotta/50 focus:ring-2 focus:ring-terracotta/10 outline-none font-body text-ink placeholder:text-ink/25 transition-all text-base"
        />
      </div>

      {/* ── Origin ────────────────────────────────────────── */}
      <div className="space-y-1.5">
        <label className="block text-xs font-medium uppercase tracking-widest text-ink/40">
          Flying from
        </label>
        <input
          type="text"
          value={origin}
          onChange={(e) => setOrigin(e.target.value)}
          placeholder="London, UK"
          required
          className="w-full px-4 py-3 rounded-xl bg-white/70 border border-sand/40 focus:border-terracotta/50 focus:ring-2 focus:ring-terracotta/10 outline-none font-body text-ink placeholder:text-ink/25 transition-all text-base"
        />
      </div>

      {/* ── Duration + Travelers row ──────────────────────── */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <label className="block text-xs font-medium uppercase tracking-widest text-ink/40">
            Days
          </label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setDuration((d) => clamp(d - 1, 1, 30))}
              className="w-9 h-9 rounded-lg border border-sand/40 bg-white/70 text-ink/60 hover:text-ink hover:border-sand transition-all font-body text-lg leading-none flex items-center justify-center"
            >
              −
            </button>
            <span className="flex-1 text-center font-display font-semibold text-ink text-xl">
              {duration}
            </span>
            <button
              type="button"
              onClick={() => setDuration((d) => clamp(d + 1, 1, 30))}
              className="w-9 h-9 rounded-lg border border-sand/40 bg-white/70 text-ink/60 hover:text-ink hover:border-sand transition-all font-body text-lg leading-none flex items-center justify-center"
            >
              +
            </button>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="block text-xs font-medium uppercase tracking-widest text-ink/40">
            Travelers
          </label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setTravelers((t) => clamp(t - 1, 1, 20))}
              className="w-9 h-9 rounded-lg border border-sand/40 bg-white/70 text-ink/60 hover:text-ink hover:border-sand transition-all font-body text-lg leading-none flex items-center justify-center"
            >
              −
            </button>
            <span className="flex-1 text-center font-display font-semibold text-ink text-xl">
              {travelers}
            </span>
            <button
              type="button"
              onClick={() => setTravelers((t) => clamp(t + 1, 1, 20))}
              className="w-9 h-9 rounded-lg border border-sand/40 bg-white/70 text-ink/60 hover:text-ink hover:border-sand transition-all font-body text-lg leading-none flex items-center justify-center"
            >
              +
            </button>
          </div>
        </div>
      </div>

      {/* ── Budget ────────────────────────────────────────── */}
      <div className="space-y-1.5">
        <label className="block text-xs font-medium uppercase tracking-widest text-ink/40">
          Budget
        </label>
        <div className="grid grid-cols-3 gap-2">
          {BUDGET_OPTIONS.map((opt) => (
            <button
              key={opt.value}
              type="button"
              onClick={() => setBudget(opt.value)}
              className={`px-3 py-3 rounded-xl border text-left transition-all ${
                budget === opt.value
                  ? "bg-terracotta border-terracotta text-parchment-50 shadow-sm"
                  : "bg-white/70 border-sand/40 text-ink hover:border-sand"
              }`}
            >
              <div className="text-sm font-medium font-body">{opt.label}</div>
              <div
                className={`text-[10px] mt-0.5 font-body ${
                  budget === opt.value ? "text-parchment-100/70" : "text-ink/35"
                }`}
              >
                {opt.desc}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* ── Departure date (optional) ─────────────────────── */}
      <div className="space-y-1.5">
        <label className="block text-xs font-medium uppercase tracking-widest text-ink/40">
          Departure date{" "}
          <span className="normal-case tracking-normal text-ink/25">
            (optional)
          </span>
        </label>
        <input
          type="date"
          value={departureDate}
          onChange={(e) => setDepartureDate(e.target.value)}
          min={new Date().toISOString().split("T")[0]}
          className="w-full px-4 py-3 rounded-xl bg-white/70 border border-sand/40 focus:border-terracotta/50 focus:ring-2 focus:ring-terracotta/10 outline-none font-body text-ink transition-all text-base"
        />
      </div>

      {/* ── Interests (optional, collapsible) ────────────── */}
      <div className="space-y-2">
        <button
          type="button"
          onClick={() => setShowInterests((s) => !s)}
          className="flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-ink/40 hover:text-ink/60 transition-colors"
        >
          <span
            className={`transition-transform text-[10px] ${showInterests ? "rotate-90" : ""}`}
          >
            ▶
          </span>
          Interests{" "}
          {interests.length > 0 && (
            <span className="normal-case tracking-normal text-terracotta">
              ({interests.length} selected)
            </span>
          )}
        </button>

        {showInterests && (
          <div className="flex flex-wrap gap-2 pt-1">
            {INTEREST_OPTIONS.map((opt) => (
              <button
                key={opt}
                type="button"
                onClick={() => toggleInterest(opt)}
                className={`px-3 py-1.5 rounded-full text-xs font-body transition-all border ${
                  interests.includes(opt)
                    ? "bg-terracotta/10 border-terracotta/40 text-terracotta"
                    : "bg-white/60 border-sand/30 text-ink/50 hover:border-sand"
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── Submit ────────────────────────────────────────── */}
      <button
        type="submit"
        disabled={!destination.trim() || !origin.trim()}
        className="w-full mt-2 bg-terracotta hover:bg-terracotta-dark disabled:opacity-40 disabled:cursor-not-allowed text-parchment-50 font-body font-medium text-base py-4 rounded-xl transition-all duration-200 shadow-md shadow-terracotta/15 hover:shadow-lg hover:shadow-terracotta/25 hover:-translate-y-0.5 active:translate-y-0"
      >
        Generate my itinerary →
      </button>
    </form>
  );
}
