const LOADING_MESSAGES = [
  "Consulting local experts…",
  "Plotting the perfect route…",
  "Sourcing hidden gems…",
  "Checking the vibe…",
  "Negotiating with jet lag…",
  "Packing your bags (metaphorically)…",
];

export default function Loading() {
  const message =
    LOADING_MESSAGES[Math.floor(Math.random() * LOADING_MESSAGES.length)];

  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] py-24 px-6">
      {/* Animated compass / spinner */}
      <div className="relative w-16 h-16 mb-8">
        <div className="absolute inset-0 rounded-full border-2 border-sand/30" />
        <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-terracotta animate-spin" />
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-2xl">✈️</span>
        </div>
      </div>

      <p className="font-display text-xl font-medium text-ink mb-2">
        Crafting your itinerary
      </p>
      <p className="font-body text-sm text-ink/40 animate-pulse">{message}</p>

      {/* Skeleton preview */}
      <div className="w-full max-w-2xl mt-12 space-y-4">
        {[...Array(5)].map((_, i) => (
          <div
            key={i}
            className="shimmer rounded-lg"
            style={{
              height: i === 0 ? "2rem" : i % 3 === 0 ? "4rem" : "1.25rem",
              width: i === 0 ? "60%" : i % 2 === 0 ? "100%" : "80%",
              animationDelay: `${i * 150}ms`,
            }}
          />
        ))}
      </div>
    </div>
  );
}
