"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import TripForm from "@/components/TripForm";
import ItineraryView from "@/components/ItineraryView";
import Loading from "@/components/Loading";
import type { TripFormData, ItineraryResponse } from "@/lib/utils";

function PlanPageContent() {
  const searchParams = useSearchParams();
  const prefillDestination = searchParams.get("destination") ?? "";

  const [itinerary, setItinerary] = useState<ItineraryResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (data: TripFormData) => {
    setIsLoading(true);
    setError(null);
    setItinerary(null);

    try {
      const res = await fetch("/api/generate-itinerary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Unknown error" }));
        throw new Error(err.error ?? `HTTP ${res.status}`);
      }

      const json = await res.json();
      setItinerary(json);
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Something went wrong. Please retry."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setItinerary(null);
    setError(null);
  };

  return (
    <div className="min-h-screen paper-bg">
      {/* ── Nav ──────────────────────────────────────────── */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 max-w-5xl mx-auto border-b border-sand/20">
        <Link
          href="/"
          className="font-display text-xl font-semibold text-ink tracking-tight"
        >
          Travel <span className="text-terracotta">OS</span>
        </Link>
        {itinerary && (
          <button
            onClick={handleReset}
            className="text-sm font-medium text-ink/50 hover:text-ink transition-colors"
          >
            ← Plan another trip
          </button>
        )}
      </nav>

      <main className="relative z-10 max-w-5xl mx-auto px-6 py-10">
        {!itinerary && !isLoading && (
          <div className="max-w-xl mx-auto">
            <div className="mb-8 text-center">
              <h1 className="font-display text-3xl md:text-4xl font-semibold text-ink mb-2">
                Plan your trip
              </h1>
              <p className="text-ink/50 font-body text-sm">
                Fill in the details below and we&apos;ll generate a personalised
                itinerary.
              </p>
            </div>
            <TripForm
              onSubmit={handleSubmit}
              prefillDestination={prefillDestination}
            />
            {error && (
              <div className="mt-4 p-4 rounded-xl bg-red-50 border border-red-100 text-sm text-red-700 font-body">
                {error}
              </div>
            )}
          </div>
        )}

        {isLoading && <Loading />}

        {itinerary && !isLoading && (
          <ItineraryView itinerary={itinerary} onReset={handleReset} />
        )}
      </main>

      {/* Background blobs */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
      >
        <div className="absolute -top-24 -right-24 w-[400px] h-[400px] rounded-full bg-terracotta/4 blur-3xl" />
        <div className="absolute bottom-0 left-0 w-[350px] h-[350px] rounded-full bg-sage/4 blur-3xl" />
      </div>
    </div>
  );
}

export default function PlanPage() {
  return (
    <Suspense fallback={<Loading />}>
      <PlanPageContent />
    </Suspense>
  );
}
