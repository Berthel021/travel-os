import { NextRequest, NextResponse } from "next/server";
import { redis } from "@/lib/redis";
import { trackEvent } from "@/lib/analytics";

export const runtime = "nodejs";

interface ConversionPayload {
  clickId: string;
  partner: string;
  value?: number;
  currency?: string;
  orderId?: string;
  type?: string;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as ConversionPayload;

    if (!body.clickId || !body.partner) {
      return NextResponse.json(
        { error: "clickId and partner are required" },
        { status: 400 }
      );
    }

    // ── Verify the click exists ────────────────────────────
    const clickData = await redis.get<Record<string, string>>(
      `click:${body.clickId}`
    );

    if (!clickData) {
      return NextResponse.json(
        { error: "Click record not found" },
        { status: 404 }
      );
    }

    // ── Record conversion in Redis ─────────────────────────
    const conversionKey = `conversion:${body.clickId}`;
    await redis.set(
      conversionKey,
      {
        clickId: body.clickId,
        partner: body.partner,
        value: body.value ?? 0,
        currency: body.currency ?? "USD",
        orderId: body.orderId ?? null,
        type: body.type ?? "booking",
        convertedAt: new Date().toISOString(),
        originalClick: clickData,
      },
      { ex: 60 * 60 * 24 * 90 } // 90-day TTL
    );

    // ── Analytics event ────────────────────────────────────
    await trackEvent("conversion_received", {
      clickId: body.clickId,
      partner: body.partner,
      value: body.value,
      currency: body.currency,
      orderId: body.orderId,
    }).catch(() => {});

    // ── Forward to n8n if configured ──────────────────────
    const n8nWebhook = process.env.N8N_CONVERSION_WEBHOOK;
    if (n8nWebhook) {
      await fetch(n8nWebhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...body, originalClick: clickData }),
        signal: AbortSignal.timeout(5000),
      }).catch(() => {});
    }

    return NextResponse.json({ success: true, clickId: body.clickId });
  } catch (error) {
    console.error("[Travel OS] Conversion webhook error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
