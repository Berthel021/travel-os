import { NextRequest, NextResponse } from "next/server";
import { generateItinerary } from "@/lib/ai/claude";
import { processItineraryResponse } from "@/lib/ai/responseProcessor";
import { trackEvent } from "@/lib/analytics";
import { generateAffiliateLinks } from "@/lib/affiliate/linkGenerator";
import type { TripFormData } from "@/lib/utils";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as TripFormData;

    // Validate required fields
    if (!body.destination || !body.origin) {
      return NextResponse.json(
        { error: "Destination and origin are required." },
        { status: 400 }
      );
    }

    // ── n8n webhook augmentation (optional) ───────────────
    const n8nWebhook = process.env.N8N_ITINERARY_WEBHOOK;
    let augmentedData = body;

    if (n8nWebhook) {
      try {
        const n8nRes = await fetch(n8nWebhook, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(5000),
        });
        if (n8nRes.ok) {
          const n8nJson = await n8nRes.json().catch(() => null);
          if (n8nJson) {
            augmentedData = { ...body, ...n8nJson };
          }
        }
      } catch {
        // Non-fatal: proceed without n8n augmentation
        console.warn("[Travel OS] n8n webhook call failed, proceeding without augmentation");
      }
    }

    // ── Generate itinerary via Claude ─────────────────────
    const rawMarkdown = await generateItinerary(augmentedData);

    // ── Post-process response ─────────────────────────────
    const processed = processItineraryResponse(rawMarkdown, augmentedData);

    // ── Build affiliate links ─────────────────────────────
    const affiliateLinks = await generateAffiliateLinks(augmentedData);

    // ── Analytics ─────────────────────────────────────────
    await trackEvent("itinerary_generated", {
      destination: body.destination,
      origin: body.origin,
      budget: body.budget,
      travelers: body.travelers,
      duration: body.duration,
    }).catch(() => {}); // Non-fatal

    return NextResponse.json({
      markdown: processed.markdown,
      destination: processed.destination,
      duration: body.duration,
      affiliateLinks,
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[Travel OS] generate-itinerary error:", error);

    const message =
      error instanceof Error ? error.message : "Internal server error";

    return NextResponse.json(
      { error: message },
      { status: 500 }
    );
  }
}
