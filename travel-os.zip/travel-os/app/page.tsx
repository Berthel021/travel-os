import Link from "next/link";

const DESTINATIONS = [
  { name: "Kyoto", country: "Japan", emoji: "⛩️" },
  { name: "Lisbon", country: "Portugal", emoji: "🌊" },
  { name: "Oaxaca", country: "Mexico", emoji: "🌮" },
  { name: "Marrakech", country: "Morocco", emoji: "🕌" },
  { name: "Queenstown", country: "New Zealand", emoji: "🏔️" },
  { name: "Tbilisi", country: "Georgia", emoji: "🍷" },
];

const FEATURES = [
  {
    icon: "✦",
    title: "AI-crafted itineraries",
    body: "Claude generates day-by-day plans tailored to your budget, pace, and interests.",
  },
  {
    icon: "✦",
    title: "Flights, hotels & activities",
    body: "Every plan includes curated booking links from trusted partners.",
  },
  {
    icon: "✦",
    title: "Ready in seconds",
    body: "No accounts. No upsells. Just your next adventure, instantly.",
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen paper-bg overflow-hidden">
      {/* ── Nav ────────────────────────────────────────────── */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 max-w-6xl mx-auto">
        <span className="font-display text-xl font-semibold text-ink tracking-tight">
          Travel <span className="text-terracotta">OS</span>
        </span>
        <Link
          href="/plan"
          className="text-sm font-medium text-ink/70 hover:text-terracotta transition-colors"
        >
          Start planning →
        </Link>
      </nav>

      {/* ── Hero ───────────────────────────────────────────── */}
      <section className="relative z-10 max-w-5xl mx-auto px-6 pt-16 pb-24 text-center">
        {/* Decorative rule */}
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="h-px w-16 bg-sand" />
          <span className="text-xs uppercase tracking-[0.2em] text-ink/40 font-body">
            AI Travel Planner
          </span>
          <div className="h-px w-16 bg-sand" />
        </div>

        <h1 className="font-display text-5xl md:text-7xl font-semibold text-ink leading-[1.08] tracking-tight mb-6">
          Your next journey,
          <br />
          <em className="text-terracotta not-italic">beautifully planned.</em>
        </h1>

        <p className="font-body text-lg md:text-xl text-ink/60 max-w-xl mx-auto mb-10 leading-relaxed">
          Describe your trip. Our AI builds a complete day-by-day itinerary
          with flights, hotels, food, and activities — in under 30 seconds.
        </p>

        <Link
          href="/plan"
          className="inline-flex items-center gap-2 bg-terracotta hover:bg-terracotta-dark text-parchment-50 font-body font-medium text-base px-8 py-4 rounded-full transition-all duration-200 shadow-lg shadow-terracotta/20 hover:shadow-xl hover:shadow-terracotta/30 hover:-translate-y-0.5"
        >
          Plan my trip
          <span className="text-lg">→</span>
        </Link>

        <p className="mt-4 text-xs text-ink/30 font-body">
          Free · No account required · Powered by Claude AI
        </p>
      </section>

      {/* ── Destination pills ──────────────────────────────── */}
      <section className="relative z-10 overflow-hidden pb-16">
        <div className="flex gap-3 animate-none justify-center flex-wrap px-6 max-w-3xl mx-auto">
          {DESTINATIONS.map((d) => (
            <Link
              key={d.name}
              href={`/plan?destination=${encodeURIComponent(d.name + ", " + d.country)}`}
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/60 border border-sand/40 hover:border-terracotta/40 hover:bg-parchment-50 transition-all text-sm font-body text-ink/70 hover:text-ink cursor-pointer"
            >
              <span>{d.emoji}</span>
              <span>
                {d.name},{" "}
                <span className="text-ink/40">{d.country}</span>
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* ── Features ───────────────────────────────────────── */}
      <section className="relative z-10 max-w-4xl mx-auto px-6 py-16 border-t border-sand/30">
        <div className="grid md:grid-cols-3 gap-8">
          {FEATURES.map((f) => (
            <div key={f.title} className="space-y-3">
              <span className="text-terracotta text-lg">{f.icon}</span>
              <h3 className="font-display font-semibold text-ink text-lg">
                {f.title}
              </h3>
              <p className="font-body text-sm text-ink/55 leading-relaxed">
                {f.body}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Footer ─────────────────────────────────────────── */}
      <footer className="relative z-10 border-t border-sand/30 py-8 px-6 text-center">
        <p className="text-xs text-ink/30 font-body">
          © {new Date().getFullYear()} Travel OS · Built with Claude AI ·
          Affiliate links support this platform
        </p>
      </footer>

      {/* ── Background decoration ──────────────────────────── */}
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-0 overflow-hidden"
      >
        <div className="absolute -top-32 -right-32 w-[600px] h-[600px] rounded-full bg-terracotta/5 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 w-[500px] h-[500px] rounded-full bg-sage/5 blur-3xl" />
      </div>
    </div>
  );
}
