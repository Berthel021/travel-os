import type { Metadata } from "next";
import "../styles/globals.css";

export const metadata: Metadata = {
  title: "Travel OS — AI-Powered Trip Planning",
  description:
    "Generate personalised day-by-day travel itineraries in seconds. Powered by AI, packed with curated recommendations.",
  keywords: ["travel planner", "AI itinerary", "trip planning", "travel OS"],
  openGraph: {
    title: "Travel OS — AI-Powered Trip Planning",
    description: "Generate your perfect trip itinerary in seconds.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
      </head>
      <body className="min-h-screen bg-parchment-100 antialiased">
        {children}
      </body>
    </html>
  );
}
