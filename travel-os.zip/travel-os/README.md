# Travel OS

**AI-powered affiliate travel planning platform.**  
Generate day-by-day itineraries with Claude AI, track affiliate clicks via Redis, and automate workflows with n8n — deployable to Vercel in minutes.

---

## Overview

Travel OS lets users:

1. Enter trip details (destination, origin, budget, duration, interests)
2. Receive a full AI-generated itinerary powered by Claude
3. Click tracked affiliate links (flights, hotels, activities, insurance)
4. Feed analytics events into n8n automation workflows

Revenue comes from affiliate commissions on bookings made through tracked redirect links.

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend + API | Next.js 14 (App Router), TypeScript, Tailwind CSS |
| AI | Anthropic Claude (`claude-sonnet-4-20250514`) |
| Storage | Upstash Redis (click tracking, conversions) |
| Automation | n8n webhooks (optional, swappable) |
| Hosting | Vercel |

---

## Project Structure

```
travel-os/
├── app/
│   ├── layout.tsx                    # Root layout
│   ├── page.tsx                      # Landing page
│   ├── plan/page.tsx                 # Trip planning page
│   └── api/
│       ├── generate-itinerary/       # POST: calls Claude, returns markdown
│       ├── out/[clickId]/            # GET: affiliate redirect + tracking
│       └── webhook/conversion/       # POST: partner conversion events
├── components/
│   ├── TripForm.tsx                  # Trip input form
│   ├── ItineraryView.tsx             # Rendered itinerary + affiliate CTAs
│   ├── AffiliateButton.tsx           # Tracked affiliate link button
│   └── Loading.tsx                   # Skeleton loading state
├── lib/
│   ├── ai/
│   │   ├── claude.ts                 # Anthropic SDK wrapper
│   │   ├── prompts.ts                # System + user prompt builders
│   │   └── responseProcessor.ts     # Markdown cleanup + metadata extraction
│   ├── affiliate/
│   │   ├── linkGenerator.ts          # Generates tracked affiliate URLs
│   │   └── router.ts                 # Redis click storage + retrieval
│   ├── redis.ts                      # Upstash Redis client
│   ├── analytics.ts                  # trackEvent() helper
│   └── utils.ts                      # Shared types + utilities
├── config/
│   └── affiliates.ts                 # Partner URLs, params, IDs
├── n8n/
│   ├── itinerary-workflow.json       # Payload augmentation webhook
│   ├── click-analytics.json          # Analytics event processing
│   └── conversion-handler.json       # Booking conversion workflow
├── styles/globals.css
├── .env.example
└── README.md
```

---

## Quick Start

### 1. Clone and install

```bash
git clone https://github.com/your-username/travel-os.git
cd travel-os
npm install
```

### 2. Configure environment

```bash
cp .env.example .env.local
```

Edit `.env.local` with your credentials:

```env
ANTHROPIC_API_KEY=sk-ant-...
UPSTASH_REDIS_REST_URL=https://your-db.upstash.io
UPSTASH_REDIS_REST_TOKEN=your-token
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 3. Run locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

---

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | ✅ | Your Anthropic API key |
| `UPSTASH_REDIS_REST_URL` | ✅ | Upstash Redis REST URL |
| `UPSTASH_REDIS_REST_TOKEN` | ✅ | Upstash Redis REST token |
| `NEXT_PUBLIC_APP_URL` | ✅ | Full app URL (used for redirect links) |
| `N8N_ITINERARY_WEBHOOK` | ☑️ | n8n webhook to augment itinerary requests |
| `N8N_ANALYTICS_WEBHOOK` | ☑️ | n8n webhook for analytics events |
| `N8N_CONVERSION_WEBHOOK` | ☑️ | n8n webhook for conversion events |
| `AFFILIATE_BOOKING_ID` | ☑️ | Booking.com affiliate ID (aid) |
| `AFFILIATE_SKYSCANNER_ID` | ☑️ | Skyscanner affiliate ID |
| `AFFILIATE_VIATOR_ID` | ☑️ | Viator affiliate ID (mcid) |
| `AFFILIATE_SAFETYWING_ID` | ☑️ | SafetyWing referral code |

✅ = Required · ☑️ = Optional but recommended for revenue

---

## Affiliate Setup

### Booking.com
1. Sign up at [booking.com/affiliate-program](https://www.booking.com/affiliate-program.html)
2. Get your `aid` number
3. Set `AFFILIATE_BOOKING_ID=your_aid`

### Skyscanner
1. Apply at [partners.skyscanner.net](https://partners.skyscanner.net)
2. Set `AFFILIATE_SKYSCANNER_ID=your_id`

### Viator
1. Join at [partnerresources.viator.com](https://partnerresources.viator.com)
2. Get your `mcid`
3. Set `AFFILIATE_VIATOR_ID=your_mcid`

### SafetyWing
1. Sign up at [safetywing.com/affiliate](https://safetywing.com/affiliate)
2. Set `AFFILIATE_SAFETYWING_ID=your_referral_code`

---

## Deployment (Vercel)

### One-click deploy

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/travel-os)

### Manual deploy

```bash
npm install -g vercel
vercel login
vercel --prod
```

Set all environment variables in your Vercel project dashboard under **Settings → Environment Variables**.

> **Important:** Set `NEXT_PUBLIC_APP_URL` to your production domain (e.g. `https://travel-os.vercel.app`).

---

## n8n Automation

Import the workflow JSONs from the `n8n/` directory into your n8n instance.

### Itinerary Augmentation (`itinerary-workflow.json`)
- Triggered before Claude is called
- Receives `TripFormData`, can enrich it (weather, events, custom instructions)
- Returns augmented data which is merged before the Claude API call
- Set webhook URL as `N8N_ITINERARY_WEBHOOK`

### Click Analytics (`click-analytics.json`)
- Receives all `trackEvent()` calls
- Routes by event type, assigns priority/category
- Extend to send to Airtable, Google Sheets, Slack, etc.
- Set webhook URL as `N8N_ANALYTICS_WEBHOOK`

### Conversion Handler (`conversion-handler.json`)
- Receives booking confirmations from affiliate partners
- Estimates commission value, flags high-value conversions
- Extend to trigger Slack alerts, update revenue dashboards
- Set webhook URL as `N8N_CONVERSION_WEBHOOK`

---

## API Reference

### `POST /api/generate-itinerary`

Generates an AI itinerary.

**Request body:**
```json
{
  "destination": "Tokyo, Japan",
  "origin": "London, UK",
  "duration": 7,
  "travelers": 2,
  "budget": "mid",
  "departureDate": "2025-03-15",
  "interests": ["Food & Drink", "History & Culture"]
}
```

**Response:**
```json
{
  "markdown": "# Tokyo: ...",
  "destination": "Tokyo, Japan",
  "duration": 7,
  "affiliateLinks": [...],
  "generatedAt": "2025-01-15T10:30:00.000Z"
}
```

---

### `GET /api/out/[clickId]`

Redirects to the affiliate partner URL while logging the click.

- Validates `clickId` against Redis
- Checks destination against an allowlist of trusted domains
- Records `followedAt` timestamp
- Fires `affiliate_clicked` analytics event
- Returns `302` redirect

---

### `POST /api/webhook/conversion`

Receives booking confirmations from affiliate partners.

**Request body:**
```json
{
  "clickId": "uuid",
  "partner": "hotels",
  "value": 350.00,
  "currency": "USD",
  "orderId": "BK123456",
  "type": "booking"
}
```

---

## Architecture

```
User
 │
 ├─ GET /           → Landing page (Next.js SSR)
 ├─ GET /plan       → Planning page (Next.js CSR)
 │
 └─ POST /api/generate-itinerary
       │
       ├─ [optional] POST N8N_ITINERARY_WEBHOOK (augment payload)
       │
       ├─ Anthropic Claude API (generate markdown)
       │
       ├─ generateAffiliateLinks()
       │     └─ storeClick() → Redis (click:{uuid})
       │
       └─ trackEvent("itinerary_generated") → N8N_ANALYTICS_WEBHOOK

User clicks affiliate link
 └─ GET /api/out/[clickId]
       ├─ getClickData() ← Redis
       ├─ markClickFollowed() → Redis
       ├─ trackEvent("affiliate_clicked") → N8N_ANALYTICS_WEBHOOK
       └─ 302 → Affiliate partner URL

Partner reports booking
 └─ POST /api/webhook/conversion
       ├─ Redis: store conversion:{clickId}
       ├─ trackEvent("conversion_received")
       └─ [optional] POST N8N_CONVERSION_WEBHOOK
```

---

## Customisation

### Add a new affiliate partner

1. Add to `config/affiliates.ts`:
```ts
myPartner: {
  baseUrl: "https://mypartner.com/search",
  param: "ref",
  affiliateId: process.env.AFFILIATE_MYPARTNER_ID,
}
```

2. Add env var to `.env.example` and `.env.local`

3. Add URL builder + link in `lib/affiliate/linkGenerator.ts`

4. Add the domain to the allowlist in `app/api/out/[clickId]/route.ts`

---

### Modify the Claude prompt

Edit `lib/ai/prompts.ts`:
- `buildSystemPrompt()` — controls output structure and style
- `buildUserPrompt()` — controls how trip data maps to the prompt

---

## Licence

MIT — use freely, build profitably.
