/**
 * Affiliate partner configuration.
 *
 * Set your partner IDs in .env.local (see .env.example).
 * The baseUrl is the landing page for each partner.
 * The param is the affiliate/tracking query parameter name.
 * affiliateId is read from the environment at runtime.
 */

export interface AffiliateConfig {
  baseUrl: string;
  param: string;
  affiliateId: string | undefined;
}

export const AFFILIATES: Record<string, AffiliateConfig> = {
  flights: {
    // Skyscanner affiliate
    baseUrl: "https://www.skyscanner.com/transport/flights/",
    param: "affiliateId",
    affiliateId: process.env.AFFILIATE_SKYSCANNER_ID,
  },
  hotels: {
    // Booking.com affiliate
    baseUrl: "https://www.booking.com/searchresults.html",
    param: "aid",
    affiliateId: process.env.AFFILIATE_BOOKING_ID,
  },
  activities: {
    // Viator affiliate
    baseUrl: "https://www.viator.com/search/",
    param: "mcid",
    affiliateId: process.env.AFFILIATE_VIATOR_ID,
  },
  insurance: {
    // SafetyWing affiliate
    baseUrl: "https://safetywing.com/nomad-insurance",
    param: "referral_code",
    affiliateId: process.env.AFFILIATE_SAFETYWING_ID,
  },
};
