import type { TripFormData } from "../utils";

export interface ProcessedItinerary {
  markdown: string;
  destination: string;
  title: string;
}

/**
 * Post-processes the raw markdown from Claude.
 * Cleans up any artefacts, extracts metadata.
 */
export function processItineraryResponse(
  raw: string,
  data: TripFormData
): ProcessedItinerary {
  // Strip any accidental code fences Claude might wrap the output in
  let markdown = raw
    .replace(/^```(?:markdown)?\n?/i, "")
    .replace(/\n?```\s*$/i, "")
    .trim();

  // Extract title from first h1 heading if present
  const titleMatch = markdown.match(/^#\s+(.+)$/m);
  const title = titleMatch
    ? titleMatch[1].trim()
    : `${data.duration}-Day Trip to ${data.destination}`;

  // Normalise line endings
  markdown = markdown.replace(/\r\n/g, "\n").replace(/\r/g, "\n");

  // Ensure no more than 2 consecutive blank lines
  markdown = markdown.replace(/\n{3,}/g, "\n\n");

  return {
    markdown,
    destination: data.destination,
    title,
  };
}
