import { redis } from "@/lib/redis";
import { v4 as uuidv4 } from "uuid";

export interface ClickData {
  originalUrl: string;
  partner: string;
  destination: string;
  source: string;
  timestamp?: string;
  followed?: boolean;
}

const CLICK_TTL_SECONDS = 60 * 60 * 24 * 30; // 30 days

/**
 * Stores click metadata in Redis and returns a unique clickId.
 */
export async function storeClick(data: Omit<ClickData, "timestamp" | "followed">): Promise<string> {
  const clickId = uuidv4();
  const key = `click:${clickId}`;

  await redis.set(
    key,
    {
      ...data,
      timestamp: new Date().toISOString(),
      followed: false,
    } satisfies ClickData,
    { ex: CLICK_TTL_SECONDS }
  );

  return clickId;
}

/**
 * Retrieves click data from Redis by clickId.
 */
export async function getClickData(clickId: string): Promise<ClickData | null> {
  return redis.get<ClickData>(`click:${clickId}`);
}

/**
 * Marks a click as followed (user redirected to affiliate).
 */
export async function markClickFollowed(clickId: string): Promise<void> {
  const key = `click:${clickId}`;
  const existing = await redis.get<ClickData>(key);

  if (existing) {
    await redis.set(
      key,
      { ...existing, followed: true, followedAt: new Date().toISOString() },
      { ex: CLICK_TTL_SECONDS }
    );
  }
}
