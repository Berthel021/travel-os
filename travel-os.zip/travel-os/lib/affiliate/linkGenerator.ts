import { AFFILIATES } from "@/config/affiliates";
import { storeClick } from "./router";
import type { TripFormData } from "../utils";

export interface AffiliateLink {
  label: string;
  description: string;
  clickUrl: string;
  partner: string;
  icon: string;
}

/**
 * Generates tracked affiliate links for a given trip.
 * Each link goes through /api/out/[clickId] for attribution.
 */
export async function generateAffiliateLinks(
  data: TripFormData
): Promise<AffiliateLink[]> {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  const links: AffiliateLink[] = [];

  // ── Flights ───────────────────────────────────────────────
  if (AFFILIATES.flights.baseUrl) {
    const flightUrl = buildFlightUrl(data);
    const clickId = await storeClick({
      originalUrl: flightUrl,
      partner: "flights",
      destination: data.destination,
      source: "itinerary",
    });
    links.push({
      label: "Search Flights",
      description: `${data.origin} → ${data.destination}`,
      clickUrl: `${appUrl}/api/out/${clickId}`,
      partner: "flights",
      icon: "✈️",
    });
  }

  // ── Hotels ────────────────────────────────────────────────
  if (AFFILIATES.hotels.baseUrl) {
    const hotelUrl = buildHotelUrl(data);
    const clickId = await storeClick({
      originalUrl: hotelUrl,
      partner: "hotels",
      destination: data.destination,
      source: "itinerary",
    });
    links.push({
      label: "Find Hotels",
      description: `Best stays in ${data.destination}`,
      clickUrl: `${appUrl}/api/out/${clickId}`,
      partner: "hotels",
      icon: "🏨",
    });
  }

  // ── Activities ────────────────────────────────────────────
  if (AFFILIATES.activities.baseUrl) {
    const activityUrl = buildActivityUrl(data);
    const clickId = await storeClick({
      originalUrl: activityUrl,
      partner: "activities",
      destination: data.destination,
      source: "itinerary",
    });
    links.push({
      label: "Book Activities",
      description: `Tours & experiences in ${data.destination}`,
      clickUrl: `${appUrl}/api/out/${clickId}`,
      partner: "activities",
      icon: "🎯",
    });
  }

  // ── Travel Insurance ──────────────────────────────────────
  if (AFFILIATES.insurance.baseUrl) {
    const insuranceUrl = buildInsuranceUrl(data);
    const clickId = await storeClick({
      originalUrl: insuranceUrl,
      partner: "insurance",
      destination: data.destination,
      source: "itinerary",
    });
    links.push({
      label: "Travel Insurance",
      description: "Protect your trip",
      clickUrl: `${appUrl}/api/out/${clickId}`,
      partner: "insurance",
      icon: "🛡️",
    });
  }

  return links;
}

// ── URL builders ──────────────────────────────────────────────

function buildFlightUrl(data: TripFormData): string {
  const { baseUrl, param } = AFFILIATES.flights;
  const url = new URL(baseUrl);
  if (param) url.searchParams.set(param, AFFILIATES.flights.affiliateId ?? "");
  url.searchParams.set("origin", encodeDestinationCode(data.origin));
  url.searchParams.set("destination", encodeDestinationCode(data.destination));
  if (data.departureDate) url.searchParams.set("outboundDate", data.departureDate);
  return url.toString();
}

function buildHotelUrl(data: TripFormData): string {
  const { baseUrl, param } = AFFILIATES.hotels;
  const url = new URL(baseUrl);
  if (param) url.searchParams.set(param, AFFILIATES.hotels.affiliateId ?? "");
  url.searchParams.set("ss", data.destination);
  url.searchParams.set("group_adults", String(data.travelers));
  return url.toString();
}

function buildActivityUrl(data: TripFormData): string {
  const { baseUrl, param } = AFFILIATES.activities;
  const url = new URL(baseUrl);
  if (param) url.searchParams.set(param, AFFILIATES.activities.affiliateId ?? "");
  url.searchParams.set("q", data.destination);
  return url.toString();
}

function buildInsuranceUrl(data: TripFormData): string {
  const { baseUrl, param } = AFFILIATES.insurance;
  const url = new URL(baseUrl);
  if (param) url.searchParams.set(param, AFFILIATES.insurance.affiliateId ?? "");
  return url.toString();
}

/** Strips country names and returns just the city for URL params */
function encodeDestinationCode(destination: string): string {
  return destination.split(",")[0].trim();
}
