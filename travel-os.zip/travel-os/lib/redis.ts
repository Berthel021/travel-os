import { Redis } from "@upstash/redis";

if (!process.env.UPSTASH_REDIS_REST_URL) {
  console.warn(
    "[Travel OS] UPSTASH_REDIS_REST_URL is not set. Redis operations will fail."
  );
}

if (!process.env.UPSTASH_REDIS_REST_TOKEN) {
  console.warn(
    "[Travel OS] UPSTASH_REDIS_REST_TOKEN is not set. Redis operations will fail."
  );
}

export const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL ?? "",
  token: process.env.UPSTASH_REDIS_REST_TOKEN ?? "",
});
