/**
 * Analytics helper for Travel OS.
 * Sends events to the configured n8n webhook (if present).
 * All calls are non-blocking — failures are swallowed so they
 * never break the main request path.
 */

export interface AnalyticsEvent {
  name: string;
  payload: Record<string, unknown>;
  timestamp: string;
}

/**
 * Track an analytics event.
 * If N8N_ANALYTICS_WEBHOOK is set, POSTs the event there.
 * Otherwise logs to stdout in development.
 */
export async function trackEvent(
  name: string,
  payload: Record<string, unknown> = {}
): Promise<void> {
  const event: AnalyticsEvent = {
    name,
    payload,
    timestamp: new Date().toISOString(),
  };

  const webhookUrl = process.env.N8N_ANALYTICS_WEBHOOK;

  if (webhookUrl) {
    try {
      await fetch(webhookUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(event),
        signal: AbortSignal.timeout(4000),
      });
    } catch (err) {
      // Non-fatal — analytics must never break the main flow
      if (process.env.NODE_ENV === "development") {
        console.warn("[Travel OS] Analytics webhook failed:", err);
      }
    }
  } else if (process.env.NODE_ENV === "development") {
    console.log(`[Analytics] ${event.name}`, event.payload);
  }
}
