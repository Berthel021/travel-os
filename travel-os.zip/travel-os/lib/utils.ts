// ─────────────────────────────────────────────────────────────
// Shared types and utility functions
// ─────────────────────────────────────────────────────────────

export type BudgetLevel = "budget" | "mid" | "premium";

export interface TripFormData {
  destination: string;
  origin: string;
  duration: number;
  travelers: number;
  budget: BudgetLevel;
  departureDate?: string;
  interests?: string[];
}

export interface AffiliateLink {
  label: string;
  description: string;
  clickUrl: string;
  partner: string;
  icon: string;
}

export interface ItineraryResponse {
  markdown: string;
  destination: string;
  duration: number;
  affiliateLinks: AffiliateLink[];
  generatedAt: string;
}

// ── Utility helpers ───────────────────────────────────────────

/**
 * Clamps a number between min and max.
 */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

/**
 * Converts a raw markdown string to safe HTML by escaping
 * only what's needed (we render via dangerouslySetInnerHTML
 * after a whitelist-based processor).
 */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

/**
 * Formats a date string (YYYY-MM-DD) to a human-readable label.
 */
export function formatDate(dateStr: string): string {
  try {
    return new Intl.DateTimeFormat("en-US", {
      day: "numeric",
      month: "long",
      year: "numeric",
    }).format(new Date(dateStr));
  } catch {
    return dateStr;
  }
}

/**
 * Returns a relative time string (e.g. "2 minutes ago").
 */
export function relativeTime(isoString: string): string {
  const diff = Date.now() - new Date(isoString).getTime();
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

/**
 * Budget level to human-readable label.
 */
export const BUDGET_LABELS: Record<BudgetLevel, string> = {
  budget: "Budget",
  mid: "Mid-Range",
  premium: "Premium",
};

/**
 * Available interest tags users can select.
 */
export const INTEREST_OPTIONS = [
  "Food & Drink",
  "History & Culture",
  "Adventure & Outdoors",
  "Art & Architecture",
  "Nightlife",
  "Family-Friendly",
  "Beaches",
  "Photography",
  "Shopping",
  "Wellness & Spa",
] as const;

export type InterestOption = (typeof INTEREST_OPTIONS)[number];
